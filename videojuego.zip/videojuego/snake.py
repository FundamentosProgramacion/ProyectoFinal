# encoding: UTF-8
# Autor: Diana Patricia Aguilar Martínez
#Para la realización de este proyecto se utilizo apoyo del libro "program arcade games with Python and Pygame"

import pygame, random, sys

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana de dibujo
pygame.display.set_caption("Juego de la vibora")
fps = pygame.time.Clock()
# Colores
BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255]
VERDE_BANDERA = (0, 122, 0)
ROJO = (255, 0, 0)
AZUL = (0, 0, 255)
NEGRO = (0,0,0)
VERDE_CLARO=(0, 225, 0)
# Variables
crecer = 0
instancia = 0


#leer archivo y guardar los datos en una lista
archivo = open("puntos.txt", "r", encoding="UTF-8")

puntaje=[]
linea= archivo.readlines()
for i in linea:
    cadena = i
    lista=cadena.split(" ")
    score= int(lista[1])
    puntaje.append([int(lista[1]), str(lista[0])])
npuntaje = sorted(puntaje, reverse=True)
archivo.close()

def guardarJugador(score):
    nombre=(input("inserte su nombre: "))
    salida= open("puntos.txt","a", encoding="UTF-8")
    salida.writelines(nombre + (" ") + str(score)+ ("\n"))
    salida.close()

def menu():
    pygame.draw.circle(ventana, BLANCO, (ANCHO // 2, ALTO // 2), 149, 0)
    pygame.draw.circle(ventana, NEGRO, (ANCHO // 2, ALTO // 2), 150, 4)
    pygame.draw.polygon(ventana, ROJO, ((335 + crecer, 215 + crecer), (335 + crecer, 385 - crecer), (485 - crecer, 300)))
    pygame.draw.circle(ventana, BLANCO, (800 - 89, 600 - 89), 78, 0)
    pygame.draw.circle(ventana,NEGRO, (800 - 90, 600 - 90), 80, 4)
    fuente = pygame.font.Font("snake.TTF", 125)
    texto1 = fuente.render("SNAKE", 1, NEGRO)
    ventana.blit(texto1, (100, 10))

#Clase de la vibora
class Snake(): #El uso de clases fue sacado del capitulo 13 del libro mencionado.
    #propiedades basicas de la vibora
    def __init__(self):
        self.posicion = [100, 60]
        self.cuerpo = [[100, 60], [80, 60], [60, 60]]
        self.direccion = "derecha"
        self.cambiarDireccionA = self.direccion

    #Funcion para cambiar de direccion
    def cambiarDireccion(self, dir):
        if dir == "derecha" and not self.direccion == "izquierda":
            self.direccion = "derecha"
        if dir == "izquierda" and not self.direccion == "derecha":
            self.direccion = "izquierda"
        if dir == "arriba" and not self.direccion == "abajo":
            self.direccion = "arriba"
        if dir == "abajo" and not self.direccion == "arriba":
            self.direccion = "abajo"

    #Funcion para mover la vibora
    def mover(self, posComida):
        if self.direccion == "derecha":
            self.posicion[0] += 20
        if self.direccion == "izquierda":
            self.posicion[0] -= 20
        if self.direccion == "arriba":
            self.posicion[1] -= 20
        if self.direccion == "abajo":
            self.posicion[1] += 20
        self.cuerpo.insert(0, list(self.posicion))
        if self.posicion == posComida:
            return 1
        else:
            self.cuerpo.pop()
            return 0

    #Checa si la vibora a chocado con la pared o con el cuerpo de la vibora
    def choques(self):
        if self.posicion[0] > 780 or self.posicion[0] < 0:
            return 1
        elif self.posicion[1] > 580 or self.posicion[1] < 0:
            return 1
        for parteCuerpo in self.cuerpo[1:]:
            if self.posicion == parteCuerpo:
                return 1
        return 0
    #Funcion que regresa la lista del cuerpo completo de la vibora
    def hacerCuerpo(self):
        return self.cuerpo

#Clase que se encarga de las funciones de la comida
class comida(): #El uso de clases fue sacado del capitulo 13 del libro mencionado.

    #Constructo basico de la clase con las propiedades basicas de la comida
    def __init__(self):
        self.posicion = [random.randrange(1, 40) * 20, random.randrange(1, 30) * 20]
        self.comidaVisible = True
    #Crear comida
    def aparecerComida(self):
        if self.comidaVisible == False:
            self.posicion = [random.randrange(1, 40) * 20, random.randrange(1, 30) * 20]
            self.comidaVisible = True
        return self.posicion
    #Alterna entre si la comida esta dibujada en la pantalla o no
    def ponerComida(self, b):
        self.comidaVisible = b

#funcion que muestra el texto de game over y el resultado
def gameOver(score):
    ventana.fill(NEGRO)
    fuente = pygame.font.Font("snake.TTF", 50)
    texto1 = fuente.render("GAME OVER!", 1, ROJO)
    texto2 = fuente.render("tu score es de: "+ str(score),1,ROJO)
    ventana.blit(texto1, (200, 200))
    ventana.blit(texto2, (50,300))


def juego(efectoCome):
    score = 0
    fuente = pygame.font.Font("snake.TTF", 20)
    texto= fuente.render("Score: "+ str(score),1,NEGRO )
    ventana.blit(texto, (10, 10))

   #crea un objeto de la clase snake y de la clase poner con las propiedades básicas declaradas en la clase
    snake = Snake()
    poner = comida()

    #loop para mover a la vibora a cada presion del teclado
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                guardarJugador(score)
                sys.exit()

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    snake.cambiarDireccion("derecha")
                if event.key == pygame.K_LEFT:
                    snake.cambiarDireccion("izquierda")
                if event.key == pygame.K_UP:
                    snake.cambiarDireccion("arriba")
                if event.key == pygame.K_DOWN:
                    snake.cambiarDireccion("abajo")
        posComida = poner.aparecerComida()
        if snake.mover(posComida) == 1:
            score += 1
            efectoCome.play()
            poner.ponerComida(False)

        #crea los colores y dibuja la vibora y la comida
        ventana.fill(VERDE_BANDERA)
        fuente = pygame.font.Font("snake.TTF", 20)
        texto = fuente.render("Score: " + str(score), 1, NEGRO)
        ventana.blit(texto, (10, 10))
        for pos in snake.hacerCuerpo():
            pygame.draw.rect(ventana,NEGRO, pygame.Rect(pos[0], pos[1], 20, 20))
        pygame.draw.rect(ventana, ROJO, pygame.Rect(posComida[0], posComida[1], 20, 20))

        #chaca si la vibora a chocado con algo en caso de ser asi el valor sera igual a 1 y el juego termina
        if snake.choques() == 1:
            efectoChoque.play()
            gameOver(score)


        pygame.display.flip()
        #establece la velocidad del juego entre mas fps, mas rápido se mueve la vibora
        fps.tick(15)

def puntuacion():

    #dibujea la ventana de scores
    pygame.draw.rect(ventana,ROJO,(10,10, ANCHO - 20, ALTO - 20))
    pygame.draw.rect(ventana, VERDE_CLARO,(200,15,400,45))
    fuente = pygame.font.Font("snake.TTF", 50)
    texto2 = fuente.render("Scores", 1, NEGRO)
    ventana.blit(texto2, (260, 12))
    for i in range(0,len(npuntaje)):
        texto2 = fuente.render(npuntaje[i][1], 1, NEGRO)
        ventana.blit(texto2, (10, i*50 + 70))
        texto2 = fuente.render(str(npuntaje[i][0]), 1, NEGRO)
        ventana.blit(texto2, (ANCHO - (30*len(str(npuntaje[i][0]))) - 55, i * 50 + 70))


#se inicia pygame
pygame.init()
ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana de dibujo
reloj = pygame.time.Clock()  # Para limitar los fps
termina = False  # Bandera para saber si termina la ejecución

#cargar los botenes
imgBack= pygame.image.load("button_back.png")

#Sprite
spriteBtnBack= pygame.sprite.Sprite()
   #asignando la imagen
spriteBtnBack.image= imgBack
   #asiganr valores de tamaño
spriteBtnBack.rect= imgBack.get_rect()
   #determinar coordenadas
spriteBtnBack.rect.left = 750 - spriteBtnBack.rect.width #coordenadas x
spriteBtnBack.rect.top = 15 #coordenadas y

#sonido
pygame.mixer.init()
efectoCome= pygame.mixer.Sound("smw_lemmy_wendy_correct.wav")
efectoChoque= pygame.mixer.Sound("smw_game_over.wav")

while not termina:

    # Detección del mouse
    mousex, mousey = pygame.mouse.get_pos()
    boton_mouse = [0]
    # Eventos
    for evento in pygame.event.get():

        if evento.type == pygame.QUIT:
            termina = True

        if evento.type == pygame.MOUSEBUTTONDOWN:
            boton_mouse[0] = 1

        if evento.type == pygame.MOUSEBUTTONUP:
            mousex, mousey = pygame.mouse.get_pos()
            boton_mouse = [0]
    #Fondo
    imgFondo= pygame.image.load("fondo.jpg")
    ventana.blit(imgFondo, (0,0))

    #Menu
    if instancia == 0:

        menu()
        if ((mousex - 400) ** 2) + ((mousey - 300) ** 2) <= 150 **2:
            if boton_mouse[0] == 1:
                instancia = 1
            crecer = 10
        else:
            crecer = 0
        if ((mousex - 710) ** 2) + ((mousey - 510) ** 2) <= 80 **2:
            if boton_mouse[0] == 1:
                instancia = 2
            trof = pygame.image.load("trof2.png")
            ventana.blit(trof, (710 - 35 , 510 - 35))
        else:
            trof = pygame.image.load("trof.png")
            ventana.blit(trof, (710 - 40, 510 - 40))



#Juego
    if instancia == 1:
        juego(efectoCome)

#Scores
    if instancia == 2:
        puntuacion()
        ventana.blit(spriteBtnBack.image, spriteBtnBack.rect)
        xbj, ybj, abj, albj = spriteBtnBack.rect
        if evento.type == pygame.MOUSEBUTTONUP:
            XM, YM = pygame.mouse.get_pos()
            # comparar coordenadas
            if XM >= xbj and XM <= xbj + abj:
                if YM >= ybj and YM <= ybj + albj:
                    instancia = 0


    pygame.display.flip()  # Actualiza trazos
    reloj.tick(40)  # 40 fps

