listao = 0
pierde = 0
