#Nataly Paulina Lopez Salazar
import pygame, random



# Dimensiones de la pantalla

ANCHO = 800

ALTO = 600

# Colores

BLANCO = (255, 255, 255)  # R,G,B en el rango [0,255]

VERDE_BANDERA = (0, 122, 0)

ROJO = (255, 0, 0)

AZUL = (0, 0, 255)

NEGRO = (0, 0, 0)



# Estructura básica de un programa que usa pygame para dibujar

def jugada(imagen, numero):
    pos = (0,0)
    if numero == 1:
        pos = (217, 115)
    elif numero == 2:
        pos = (340, 117)
    elif numero == 3:
        pos = (488, 118)
    elif numero == 4:
        pos = (214, 217)
    elif numero == 5:
        pos = (341, 219)
    elif numero == 6:
        pos = (489, 217)
    elif numero == 7:
        pos = (220, 361)
    elif numero == 8:
        pos = (341, 361)
    elif numero == 9:
        pos = (490, 360)
    if imagen == "x":
        ventana.blit(imgX,pos)
    elif imagen == "o":
        ventana.blit(imgO,pos)



# Inicializa el motor de pygame

pygame.init()

ventana = pygame.display.set_mode((ANCHO, ALTO))  # Crea la ventana de dibujo

reloj = pygame.time.Clock()  # Para limitar los fps

termina = False  # Bandera para saber si termina la ejecución

#Imagenes
fondo = pygame.image.load("fondo.png")
btJugar = pygame.image.load("button_jugar.png")
btCreditos = pygame.image.load("button_creditos.png")
tablero = pygame.image.load("Tablero2.jpg")
regreso = pygame.image.load("boton_atras.png")


spritebtJugar = pygame.sprite.Sprite()
spritebtJugar.image = btJugar
spritebtJugar.rect = btJugar.get_rect()
spritebtJugar.rect.left = ANCHO//2 -spritebtJugar.rect.width//2
spritebtJugar.rect.top = ALTO//3

spritebtCreditos = pygame.sprite.Sprite()
spritebtCreditos.image = btCreditos
spritebtCreditos.rect = btCreditos.get_rect()
spritebtCreditos.rect.left = ANCHO // 2 - spritebtCreditos.rect.width // 2
spritebtCreditos.rect.top = 2*ALTO // 3

spritetablero = pygame.sprite.Sprite()
spritetablero.image = tablero
spritetablero.rect = tablero.get_rect()
spritetablero.rect.left = ANCHO// 2-spritetablero.rect.width // 2

spriteregreso = pygame.sprite.Sprite()
spriteregreso.image = regreso
spriteregreso.rect = regreso.get_rect()
spriteregreso.rect.left = ANCHO//7 - spriteregreso.rect.width // 2
spriteregreso.rect.top =2* ALTO //3

#X y O
imgX = pygame.image.load("x.png")
x = pygame.sprite.Sprite()
x.image = imgX
x.rect = imgX.get_rect()

imgO = pygame.image.load("O.png")


#Ventanas del juego
MENU = 1
juego = 2
creditos = 3
gana = 4
pierde = 5
ventanas = MENU
boton = False
listageneral = [1,2,3,4,5,6,7,8,9]
listax = []
listao =[]
jugador1 = True
cooldown = 0
#Fuente de texto
fuente = pygame.font.SysFont("arial", 60)


while not termina:  ##  Ciclo principal
    mousex, mousey = pygame.mouse.get_pos()
    # Procesa los eventos que recibe el programa

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
            termina = True

        if evento.type == pygame.MOUSEBUTTONDOWN:
                boton = True
                xm,ym = pygame.mouse.get_pos()
                if ventanas ==MENU:
                    xbj,ybj,abj,albj = spritebtJugar.rect
                    if xm >= xbj and xm <= xbj + abj:
                        if ym >= ybj and ym <= ybj + albj:
                            ventanas = juego
                        else:
                            ventanas = creditos

                elif ventanas == juego or ventanas == creditos:
                    xba,yba,aba,alba = spriteregreso.rect
                    if xm >= xba and xm <= xba + aba:
                        if ym >= yba and ym <= yba + alba:
                            ventanas = MENU
        else:
            boton = False






    # Borrar pantalla

    ventana.fill(NEGRO)



    # Dibujar, aquí haces todos los trazos que requieras

    # Normalmente llamas a otra función y le pasas -ventana- como parámetro, por ejemplo, dibujarLineas(ventana)

    if ventanas == MENU:
        ventana.blit(fondo,(0,0))
        ventana.blit(spritebtJugar.image,spritebtJugar.rect)
        ventana.blit(spritebtCreditos.image,spritebtCreditos.rect)
        titulo = fuente.render("TIC TAC TOE",1,AZUL)
        ventana.blit(titulo,(ANCHO//2-150,ALTO//7))

    elif ventanas == juego:
        ventana.blit (spritetablero.image,spritetablero.rect)
        ventana.blit(spriteregreso.image,spriteregreso.rect)
        if jugador1:
            if 217 <= mousex <= 329 and 115 <= mousey <= 209 and boton:
                for i in listageneral:
                    if i == 1:
                        listax.append(1)
                        listageneral.remove(1)
                        jugador1 = False
            elif 340 <= mousex <= 477 and 117 <= mousey <= 205 and boton:
                for i in listageneral:
                    if i == 2:
                        listax.append(2)
                        listageneral.remove(2)
                        jugador1 = False
            elif 488 <= mousex <= 579 and 118 <= mousey <= 206 and boton:
                for i in listageneral:
                    if i == 3:
                        listax.append(3)
                        listageneral.remove(3)
                        jugador1 = False
            elif 214 <= mousex <= 328 and 217 <= mousey <= 347 and boton:
                for i in listageneral:
                    if i == 4:
                        listax.append(4)
                        listageneral.remove(4)
                        jugador1 = False
            elif 341 <= mousex <= 476 and 219 <= mousey <= 348 and boton:
                for i in listageneral:
                    if i == 5:
                        listax.append(5)
                        listageneral.remove(5)
                        jugador1 = False
            elif 489 <= mousex <= 579 and 217 <= mousey <= 349 and boton:
                for i in listageneral:
                    if i == 6:
                        listax.append(6)
                        listageneral.remove(6)
                        jugador1 = False
            elif 220 <= mousex <= 326 and 361 <= mousey <= 457 and boton:
                for i in listageneral:
                    if i == 7:
                        listax.append(7)
                        listageneral.remove(7)
                        jugador1 = False
            elif 341 <= mousex <= 476 and 361 <= mousey <= 457 and boton:
                for i in listageneral:
                    if i == 8:
                        listax.append(8)
                        listageneral.remove(8)
                        jugador1 = False
            elif 490 <= mousex <= 5766 and 360 <= mousey <= 458 and boton:
                for i in listageneral:
                    if i == 9:
                        listax.append(9)
                        listageneral.remove(9)
                        jugador1 = False
        if not jugador1:
            valor = listageneral[random.randint(0,len(listageneral) - 1)]
            listao.append(valor)
            listageneral.remove(valor)
            jugador1 = True

        for i in listax:
            jugada("x", i)
        for i in listao:
            jugada("o",i)

        for i in listax:
            if i == 1:
                for i in listax:
                    if i == 2:
                        for i in listax:
                            if i ==3:
                                ventanas = gana
                    if i == 4:
                        for i in listax:
                            if i == 7:
                                ventanas = gana
                    if i == 5:
                        for i in listax:
                            if i == 9:
                                ventanas = gana
            elif i == 2:
                for i in listax:
                    if i == 5:
                        for i in listax:
                            if i == 8:
                                ventanas = gana
            elif i == 3:
                for i in listax:
                    if i == 6:
                        for i in listax:
                            if i == 9:
                                ventanas = gana
                    if i == 5:
                        for i in listax:
                            if i == 7:
                                ventanas = gana
            elif i == 4:
                for i in listax:
                    if i == 5:
                        for i in listax:
                            if i == 6:
                                ventanas = gana
            elif i == 7:
                for i in listax:
                    if i == 8:
                        for i in listax:
                            if i == 9:
                                ventanas = gana
        for i in listao:
            if i == 1:
                for i in listao:
                    if i == 2:
                        for i in listao:
                            if i == 3:
                                ventanas = pierde
                    if i == 4:
                        for i in listao:
                            if i == 7:
                                ventanas = pierde
                    if i == 5:
                        for i in listao:
                            if i == 9:
                                ventanas = pierde
            elif i == 2:
                for i in listao:
                    if i == 5:
                        for i in listao:
                            if i == 8:
                                ventanas = pierde
            elif i == 3:
                for i in listao:
                    if i == 6:
                        for i in listao:
                            if i == 9:
                                ventanas = pierde
                    if i == 5:
                        for i in listao:
                            if i == 7:
                                ventanas = pierde
            elif i == 4:
                for i in listao:
                    if i == 5:
                        for i in listao:
                            if i == 6:
                                ventanas = pierde
            elif i == 7:
                for i in listao:
                    if i == 8:
                        for i in listao:
                            if i == 9:
                                ventanas = pierde
        if len(listageneral)==0:
            ventanas = pierde

    elif ventanas == gana:
        gg = fuente.render("GANASTE", 1, BLANCO)
        ventana.blit(gg, (20,ALTO//2))
        if boton:
            ventanas = creditos
        listageneral = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        listax = []
        listao = []
    elif ventanas == pierde:
        L = fuente.render("PERDISTE", 1, BLANCO)
        ventana.blit(L, (20, ALTO // 2))
        if boton:
            ventanas = creditos
        listageneral = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        listax = []
        listao = []
    elif ventanas == creditos:
        nombre = fuente.render("Nataly Paulina",1,BLANCO)
        apellido = fuente.render("López Salazar",1,BLANCO)
        matricula = fuente.render("A01746299",1,BLANCO)
        ventana.blit(nombre,(ANCHO//2-150,ALTO//7))
        ventana.blit(apellido,(ANCHO//2-150,2*ALTO//5))
        ventana.blit(matricula,(ANCHO//2-150,2*ALTO//3))
        ventana.blit(spriteregreso.image, spriteregreso.rect)





    pygame.display.flip()  # Actualiza trazos

    reloj.tick(10)  # 40 fps



# Después del ciclo principal

pygame.quit()  # termina pygame